# ThreadContinue
Reflective DLL injection using SetThreadContext() and NtContinue()

https://zerosum0x0.blogspot.com/2017/07/threadcontinue-reflective-injection.html

#### Acknowledgement

This code re-uses Stephen Fewer's widely-used reflective DLL.

https://raw.githubusercontent.com/stephenfewer/ReflectiveDLLInjection
